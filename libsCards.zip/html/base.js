let h1 = document.querySelector('h1');
h1.innerHTML = "Javascript OK"