const usernameCookie = document.cookie.split("=")[1];

if (usernameCookie === undefined) {
    window.location.href = "./";
}

const baseUrl = "http://localhost:8080";
let trmsNewRequestButtonActive = false;
const trmsNewRequestButton = document.getElementById('trmsNewRequestButton');
trmsNewRequestButton.addEventListener('click', requestToggle);
const trmsNewRequestForm = document.getElementById('trmsNewRequestForm');
const trmsInputSupervisor = document.getElementById('trmsInputSupervisor');
const trmsInputProjected = document.getElementById('trmsInputProjected');
const trmsInputCost = document.getElementById('trmsInputCost');
trmsInputCost.addEventListener('change', updateCost);
const trmsInputEventType = document.getElementById('trmsInputEventType');
trmsInputEventType.addEventListener('change', updateEventType);
const trmsSubmitRequestButton = document.getElementById('trmsSubmitRequestButton');
trmsSubmitRequestButton.addEventListener('click', submitRequest);
const trmsLogoutButton = document.getElementById('trmsLogoutButton');
trmsLogoutButton.addEventListener('click', clientLogout);
let employeeList;
let requestList;
const requestArray = [];
let AvailableReimburstment = 1000;
let EventType = 0;
let Cost = 0;
let updatePR;


window.onload = async function() {
    const res = await fetch(`${baseUrl}/employeeList`);
    const restwo = await fetch(`${baseUrl}/requestList`);
    let option;

    if (res.status === 200) {
        employeeList = await res.json();
        for (const element of employeeList) {
            if (element.employSupervisor) {
                option = document.createElement("option");
                option.text = element.employName;
                trmsInputSupervisor.add(option);
            }
        }
    }

    if (restwo.status === 200) {
        requestList = await restwo.json();
        for (const element of requestList) {
            if ((usernameCookie == element.reqRequestingInfoSend) ||
                (usernameCookie == element.reqRequestingInfoReceive)) {
                    //requestArray.push(element);
                    if (usernameCookie == element.reqRequester) {
                        AvailableReimburstment = Math.max(AvailableReimburstment - element.reqReimbursement, 0);
                    }
                    let divNode = document.createElement("div");
                    divNode.className = "d-flex justify-content-center";
                    const tableNode = document.createElement("TABLE");
                    tableNode.className = "table table-striped table-hover table-dark"
                    const header = tableNode.createTHead();
                    const row = header.insertRow(0);
                    const x = document.createElement("TBODY");
                    const y = document.createElement("TR");
                    
                    let cell = row.insertCell(0);
                    cell.innerHTML = "<b>Requester</b>";
                    let z = document.createElement("TD");
                    z.innerHTML = getRealName(element.reqRequester);
                    y.appendChild(z);

                    cell = row.insertCell(1);
                    cell.innerHTML = "<b>Reimbursement</b>";
                    z = document.createElement("TD");
                    z.innerHTML = ("$" + element.reqReimbursement);
                    y.appendChild(z);

                    cell = row.insertCell(2);
                    cell.innerHTML = "<b>Event Type</b>";
                    z = document.createElement("TD");
                    z.innerHTML = returnEventType(element.reqEventType);
                    y.appendChild(z);

                    cell = row.insertCell(3);
                    cell.innerHTML = "<b>Description</b>";
                    z = document.createElement("TD");
                    z.innerHTML = element.reqDescription;
                    y.appendChild(z);

                    cell = row.insertCell(4);
                    cell.innerHTML = "<b>Grade Format</b>";
                    z = document.createElement("TD");
                    z.innerHTML = returnGradeFormat(element.reqGradeFormat);
                    y.appendChild(z);

                    cell = row.insertCell(5);
                    cell.innerHTML = "<b>Passing Grade Cutoff</b>";
                    z = document.createElement("TD");
                    z.innerHTML = (element.reqPassingCutoff == "" ? returnGradeDefault(element.reqGradeFormat) : element.reqPassingCutoff);
                    y.appendChild(z);

                    cell = row.insertCell(6);
                    cell.innerHTML = "<b>Location</b>";
                    z = document.createElement("TD");
                    z.innerHTML = element.reqLocation;
                    y.appendChild(z);

                    cell = row.insertCell(7);
                    cell.innerHTML = "<b>Start Date</b>";
                    z = document.createElement("TD");
                    z.innerHTML = ((element.reqStartDate < (Date.now() + 12096e5)) ? `<b style="color:red;">${((new Date(element.reqStartDate)).toString().substring(0,15))}</b>` : ((new Date(element.reqStartDate)).toString().substring(0,15)));
                    y.appendChild(z);

                    cell = row.insertCell(8);
                    cell.innerHTML = "<b>Est. Work Hours Missed</b>";
                    z = document.createElement("TD");
                    z.innerHTML = element.reqWorkHoursMissed;
                    y.appendChild(z);

                    cell = row.insertCell(9);
                    cell.innerHTML = "<b>Work-related Justification</b>";
                    z = document.createElement("TD");
                    z.innerHTML = element.reqRelateJustify;
                    y.appendChild(z);

                    x.appendChild(y);
                    tableNode.appendChild(x);
                    divNode.appendChild(tableNode);
                    document.body.appendChild(divNode);

                    divNode = document.createElement("div");
                    divNode.className = "d-flex justify-content-start";

                    const phaseCheck = getphaseCheck(element, usernameCookie);

                    if (element.reqBenefitCFinalGradeStatus != 2) {
                        const pNode = document.createElement("p");
                        pNode.innerHTML = `| <b>${getRealName(element.reqRequestingInfoSend)}</b>: ${getElementMessage(element, element.reqRequestingInfoSend)}`;
                        divNode.appendChild(pNode);
                    }
                    
                    document.body.appendChild(divNode);

                    divNode = document.createElement("div");
                    divNode.className = "d-flex justify-content-around";

                    const myTurn = (usernameCookie == element.reqRequestingInfoReceive);
                    
                    
                    const inputNode = document.createElement("INPUT");
                    inputNode.setAttribute("type", "text");
                    inputNode.setAttribute("class", "form-control");
                    inputNode.myParam = element;
                    inputNode.readOnly = !myTurn;
                    divNode.appendChild(inputNode);

                    let buttonNode;

                    if (phaseCheck == 2) {
                        buttonNode = document.createElement("button");
                        buttonNode.innerHTML = "Submit";
                        buttonNode.setAttribute("class", "btn btn-primary");
                        buttonNode.myParam = inputNode;
                        buttonNode.myParamNumber = 0;
                        buttonNode.disabled = !myTurn;
                        if (element.reqBenefitCFinalGradeStatus == 2) {
                            buttonNode.disabled = true;
                        }
                        buttonNode.addEventListener('click', trmsButtonAction);
                        divNode.appendChild(buttonNode);
                    }

                    if (phaseCheck == 1) {
                        buttonNode = document.createElement("button");
                        buttonNode.innerHTML = "Approve";
                        buttonNode.setAttribute("class", "btn btn-primary");
                        buttonNode.myParam = inputNode;
                        buttonNode.myParamNumber = 2;
                        buttonNode.disabled = !myTurn;
                        buttonNode.addEventListener('click', trmsButtonAction);
                        divNode.appendChild(buttonNode);

                        buttonNode = document.createElement("button");
                        buttonNode.innerHTML = "Deny";
                        buttonNode.setAttribute("class", "btn btn-primary");
                        buttonNode.myParam = inputNode;
                        buttonNode.myParamNumber = 1;
                        buttonNode.disabled = !myTurn;
                        buttonNode.addEventListener('click', trmsButtonAction);
                        divNode.appendChild(buttonNode);

                        if (usernameCookie == element.reqSupervisor || usernameCookie == element.reqDepartmentHead || usernameCookie == element.reqBenefitsCoordinator) {
                            buttonNode = document.createElement("button");
                            buttonNode.innerHTML = `Request Info From Requester: ${getRealName(element.reqRequester)}`;
                            buttonNode.setAttribute("class", "btn btn-primary");
                            buttonNode.myParam = inputNode;
                            buttonNode.myParamNumber = 9;
                            buttonNode.disabled = !myTurn;
                            buttonNode.addEventListener('click', trmsButtonAction);
                            divNode.appendChild(buttonNode);
                        }

                        if (usernameCookie == element.reqDepartmentHead || usernameCookie == element.reqBenefitsCoordinator) {
                            buttonNode = document.createElement("button");
                            buttonNode.innerHTML = `Request Info From Supervisor: ${getRealName(element.reqSupervisor)}`;
                            buttonNode.setAttribute("class", "btn btn-primary");
                            buttonNode.myParam = inputNode;
                            buttonNode.myParamNumber = 8;
                            buttonNode.disabled = !myTurn;
                            buttonNode.addEventListener('click', trmsButtonAction);
                            divNode.appendChild(buttonNode);
                        }

                        if (usernameCookie == element.reqBenefitsCoordinator) {
                            buttonNode = document.createElement("button");
                            buttonNode.innerHTML = `Request Info From Department Head: ${getRealName(element.reqDepartmentHead)}`;
                            buttonNode.setAttribute("class", "btn btn-primary");
                            buttonNode.myParam = inputNode;
                            buttonNode.myParamNumber = 7;
                            buttonNode.disabled = !myTurn;
                            buttonNode.addEventListener('click', trmsButtonAction);
                            divNode.appendChild(buttonNode);
                        }
                    }
                    document.body.appendChild(divNode);
            }
        }
        document.body.appendChild(document.createElement("hr"));
    }
}

function setElementMessage(elementBase, userName, newMessage) {
    for (const element of employeeList) {
        if (element.employUsername == userName) {
            if (element.employBenefitsCoordinator) {
                return (elementBase.reqBenefitCInfo = newMessage);
            }
            if (element.employDepartmentHead) {
                return (elementBase.reqDepartHInfo = newMessage);
            }
            if (element.employSupervisor) {
                return (elementBase.reqDirectSuInfo = newMessage);
            }
            return (elementBase.reqEmployeeInfo = newMessage);
        }
    }
}

function approveRequest(elementBase, userName) {
    for (const element of employeeList) {
        if (element.employUsername == userName) {
            if (element.employBenefitsCoordinator) {
                if (elementBase.reqBenefitCStatus == 2)
                {
                    elementBase.reqBenefitCFinalGradeStatus = 2;
                    return;
                }
                elementBase.reqRequestingInfoSend = elementBase.reqBenefitsCoordinator;
                elementBase.reqRequestingInfoReceive = elementBase.reqRequester;
                return (elementBase.reqBenefitCStatus = 2);
            }
            if (element.employDepartmentHead) {
                elementBase.reqRequestingInfoSend = elementBase.reqDepartmentHead;
                elementBase.reqRequestingInfoReceive = elementBase.reqBenefitsCoordinator;
                return (elementBase.reqDepartHStatus = 2);
            }
            if (element.employSupervisor) {
                elementBase.reqRequestingInfoSend = elementBase.reqSupervisor;
                elementBase.reqRequestingInfoReceive = elementBase.reqDepartmentHead;
                return (elementBase.reqDirectSuStatus = 2);
            }
            return;
        }
    }
}

function getElementMessage(elementBase, userName) {
    for (const element of employeeList) {
        if (element.employUsername == userName) {
            if (element.employBenefitsCoordinator) {
                return elementBase.reqBenefitCInfo;
            }
            if (element.employDepartmentHead) {
                return elementBase.reqDepartHInfo;
            }
            if (element.employSupervisor) {
                return elementBase.reqDirectSuInfo;
            }
            return elementBase.reqEmployeeInfo;
        }
    }
}

function getphaseCheck(elementBase, userName) {
    // 1 = higherup button, 2 = requester, 3 = waiting
    for (const element of employeeList) {
        if (element.employUsername == userName) {
            if (elementBase.reqRequester == userName) {
                return 2;
            }
            if (element.employBenefitsCoordinator) {
                return (elementBase.reqBenefitCFinalGradeStatus == 0 ? 1 : 3);
            }
            if (element.employDepartmentHead) {
                // 0 = init, 1 = deny, 2 = approved
                if (elementBase.reqDepartHStatus == 0) {
                    return 1;
                }
                if (elementBase.reqDepartHStatus == 1) {
                    return 1;
                }
                if (elementBase.reqDepartHStatus == 2) {
                    return 2;
                }
            }
            if (element.employSupervisor) {
                if (elementBase.reqDirectSuStatus == 0) {
                    return 1;
                }
                if (elementBase.reqDirectSuStatus == 1) {
                    return 1;
                }
                if (elementBase.reqDirectSuStatus == 2) {
                    return 2;
                }
            }
            return 2;
        }
    }

}

function getRealName(userName) {
    for (const element of employeeList) {
        if (element.employUsername == userName) {
            return element.employName;
        }
    }
}

function UpdateProjectedReimburstment() {
    trmsInputProjected.value = (Math.min(AvailableReimburstment, Cost*EventType) + 0.0001);
    trmsInputProjected.value = trmsInputProjected.value.replace(/(?<=\.\d\d).*/g, "");
    trmsInputProjected.value = trmsInputProjected.value.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    trmsInputProjected.value = `$${trmsInputProjected.value}`;
}

function updateCost() {
    Cost = trmsInputCost.valueAsNumber
}

function updateEventType() {
    switch (trmsInputEventType.selectedIndex) {
        case 1:
            EventType = 0.8;
        break;
        case 2:
            EventType = 0.6;
        break;
        case 3:
            EventType = 0.75;
        break;
        case 4:
            EventType = 1;
        break;
        case 5:
            EventType = 0.9;
        break;
        case 6:
            EventType = 0.3;
        break;
        default:
            EventType = 0;
    }
}

function returnEventType(eventTypeNumber) {
    switch (eventTypeNumber) {
        case 1:
            return "University Course";
        break;
        case 2:
            return "Seminar";
        break;
        case 3:
            return "Certification Preparation Class";
        break;
        case 4:
            return "Certification";
        break;
        case 5:
            return "Technical Training";
        break;
        case 6:
            return "Other";
        break;
        default:
            return "Other";
    }
}

function returnGradeFormat(gradeFormatNumber) {
    switch (gradeFormatNumber) {
        case 1:
            return "Pass / Fail";
        break;
        case 2:
            return "Percent";
        break;
        case 3:
            return "Letter";
        break;
        default:
            return "Pass / Fail";
    }
}

function returnGradeDefault(gradeFormatNumber) {
    switch (gradeFormatNumber) {
        case 1:
            return "Pass";
        break;
        case 2:
            return "80%";
        break;
        case 3:
            return "C";
        break;
        default:
            return "Pass";
    }
}

function requestToggle() {
    trmsNewRequestButtonActive = !trmsNewRequestButtonActive;

    if (trmsNewRequestButtonActive) {
        trmsNewRequestForm.className = "d-flex justify-content-center";
        trmsNewRequestButton.innerHTML = "Cancel Request";
        updatePR = setInterval(UpdateProjectedReimburstment, 1000);
    } else {
        trmsNewRequestForm.className = "visually-hidden";
        trmsNewRequestButton.innerHTML = "New Request";
        clearInterval(updatePR);
    }
}

function clientLogout() {
    document.cookie = `employUsername=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
    window.location.href = "./";
}

async function submitRequest() {
    trmsSubmitRequestButton.innerHTML = "Sending Request...";
    trmsSubmitRequestButton.disabled = true;
    const trmsInputDepartment = document.getElementById('trmsInputDepartment');
    const reqReimbursementNumber = Number(trmsInputProjected.value.substring(1));
    const trmsInputSupervisor = document.getElementById('trmsInputSupervisor');
    let reqDepartmentHeadName;
    let reqRequesterName;
    let reqSupervisorName;
    let reqBenefitsCoordinatorName;

    for (const element of employeeList) {
        if (element.employDepartmentHead) {
            if (element.employDepartment == trmsInputDepartment.selectedIndex) {
                reqDepartmentHeadName = element.employUsername;
            }
        }
        if (element.employUsername == usernameCookie) {
            reqRequesterName = element.employUsername;
        }
        if (element.employName == trmsInputSupervisor.value) {
            reqSupervisorName = element.employUsername;
        }
        if (element.employBenefitsCoordinator) {
            reqBenefitsCoordinatorName = element.employUsername;
        }
    }

    const newRequest = {
        reqEventType: trmsInputEventType.selectedIndex,
        reqCost: trmsInputCost.valueAsNumber,
        reqStartDate: document.getElementById('trmsInputDateTime').valueAsNumber,
        reqLocation: document.getElementById('trmsInputLocation').value,
        reqDescription: document.getElementById('trmsInputDescription').value,
        reqGradeFormat:  document.getElementById('trmsInputGradeFormat').selectedIndex,
        reqPassingCutoff:  document.getElementById('trmsInputPassingGradeCutoff').value,
        reqRelateJustify:  document.getElementById('trmsInputJustification').value,
        reqWorkHoursMissed:  document.getElementById('trmsInputHoursMissed').valueAsNumber,
        reqSupervisor:  reqSupervisorName,
        reqDepartmentHead: reqDepartmentHeadName,
        reqReimbursement: (reqReimbursementNumber ? reqReimbursementNumber : 1000),
        reqAutoApproveDeadline: (Date.now() + 12096e5),
        reqExceedingFunds: false,
        reqRequester: reqRequesterName,
        reqBenefitsCoordinator: reqBenefitsCoordinatorName,
        reqRequestCanceled: false,
        reqRequestingInfoSend: reqRequesterName,
        reqRequestingInfoReceive: reqSupervisorName,
        reqEmployeeInfo: document.getElementById('trmsInputJustification').value,
        reqDirectSuInfo: "",
        reqDepartHInfo: "",
        reqBenefitCInfo: "",
        reqDirectSuStatus: 0,
        reqDepartHStatus: 0,
        reqBenefitCStatus: 0,
        reqFinalGrade: "",
        reqBenefitCFinalGradeStatus: 0,
        reqArchived: false,
    }

    const res = await fetch(`${baseUrl}/postRequest`, {
        method: "POST",
        body: JSON.stringify(newRequest)
    });

    if (res.status === 201) {
        window.location.href = "./request.html";
    }
}

async function trmsButtonAction() {
    event.currentTarget.innerHTML = "Sending...";
    event.currentTarget.disabled = true;
    if (event.currentTarget.myParamNumber == 2) {
        approveRequest(event.currentTarget.myParam.myParam, usernameCookie)
    } else if (event.currentTarget.myParamNumber == 7) {
        event.currentTarget.myParam.myParam.reqRequestingInfoSend = event.currentTarget.myParam.myParam.reqRequestingInfoReceive;
        event.currentTarget.myParam.myParam.reqRequestingInfoReceive = event.currentTarget.myParam.myParam.reqDepartmentHead;
    } else if (event.currentTarget.myParamNumber == 8) {
        event.currentTarget.myParam.myParam.reqRequestingInfoSend = event.currentTarget.myParam.myParam.reqRequestingInfoReceive;
        event.currentTarget.myParam.myParam.reqRequestingInfoReceive = event.currentTarget.myParam.myParam.reqSupervisor;
    } else if (event.currentTarget.myParamNumber == 9) {
        event.currentTarget.myParam.myParam.reqRequestingInfoSend = event.currentTarget.myParam.myParam.reqRequestingInfoReceive;
        event.currentTarget.myParam.myParam.reqRequestingInfoReceive = event.currentTarget.myParam.myParam.reqRequester;
    }
    else {
        const tempSwap = event.currentTarget.myParam.myParam.reqRequestingInfoSend;
        event.currentTarget.myParam.myParam.reqRequestingInfoSend = event.currentTarget.myParam.myParam.reqRequestingInfoReceive;
        event.currentTarget.myParam.myParam.reqRequestingInfoReceive = tempSwap;
    }

    setElementMessage(event.currentTarget.myParam.myParam, event.currentTarget.myParam.myParam.reqRequestingInfoSend, event.currentTarget.myParam.value)

    const res = await fetch(`${baseUrl}/updateRequest`, {
        method: "PUT",
        body: JSON.stringify(event.currentTarget.myParam.myParam)
    });

    if (res.status === 200) {
        window.location.href = "./request.html";
    }
}