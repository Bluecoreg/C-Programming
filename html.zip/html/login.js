const baseUrl = "http://ec2-100-27-25-68.compute-1.amazonaws.com:8080";

const trmsLoginButton = document.getElementById('trmsLoginButton');
trmsLoginButton.addEventListener('click', clientLogin);

window.onload = async function() {
    const res = await fetch(`${baseUrl}/login`, {
        method: "POST",
        body: document.cookie.split("=")[1]
    });

    if (res.status === 200) {
        const data = await res.json();
        if (!(Object.keys(data).length === 0)) {
            window.location.href = "./request.html";
        }
    }
}

async function clientLogin() {
    trmsLoginButton.innerHTML = "Logging In...";
    trmsLoginButton.disabled = true;
    const trmsInputUsername = document.getElementById('trmsInputUsername');
    const trmsInputPassword = document.getElementById('trmsInputPassword');

    const res = await fetch(`${baseUrl}/login`, {
        method: "POST",
        body: trmsInputUsername.value
    });

    if (res.status === 200) {
        const data = await res.json();
        if (Object.keys(data).length === 0) {
            trmsLoginButton.innerHTML = "Incorrect Username!";
            trmsLoginButton.disabled = false;
        } else if (data.employPassword != trmsInputPassword.value) {
            trmsLoginButton.innerHTML = "Incorrect Password!";
            trmsLoginButton.disabled = false;
        } else {
            document.cookie = `employUsername=${trmsInputUsername.value}; expires=Thu, 01 Jan 2970 00:00:00 UTC; path=/;`;
            window.location.href = "./request.html";
        }
    }
    else {
        trmsLoginButton.innerHTML = "Unable to Login!";
        trmsLoginButton.disabled = false;
    }
}